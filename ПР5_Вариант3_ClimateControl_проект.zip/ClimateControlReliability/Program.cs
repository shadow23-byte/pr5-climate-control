using System.Text;
using ClimateControlReliability;

const long now = 1_800_000_000;
var store = new DemoStore();
var gateway = new ClimateGateway(Encoding.UTF8.GetBytes("pr5-demo-key-for-classroom-only"), store);
var first = new ClimateMessage("room-101", 22_400, now, []);
first = first with { Signature = gateway.Sign(first) };
var second = new ClimateMessage("room-202", 23_100, now + 1, []);
second = second with { Signature = gateway.Sign(second) };

int passed = 0;
void Check(string name, bool ok)
{
    Console.WriteLine($"{(ok ? "PASS" : "FAIL")} | {name}");
    if (ok) passed++;
}

Check("Подлинное показание сохранено", gateway.Ingest(first, now) == IngestResult.Stored);
Check("Подмена отклонена", gateway.Ingest(first with { TemperatureMilliCelsius = 24_000 }, now) == IngestResult.Rejected);
Check("Пустая подпись отклонена", gateway.Ingest(second with { Signature = [] }, now) == IngestResult.Rejected);
store.Available = false;
Check("Сбой хранилища: запись в очереди", gateway.Ingest(second, now) == IngestResult.Queued && gateway.PendingCount == 1);
Check("Повтор показания отклонён", gateway.Ingest(second, now) == IngestResult.Rejected);
Check("Очередь сохраняется во время сбоя", gateway.FlushPending() == 0 && gateway.PendingCount == 1);
store.Available = true;
Check("После восстановления очередь очищена", gateway.FlushPending() == 1 && gateway.PendingCount == 0 && store.Records.Count == 2);
Console.WriteLine($"Итог: {passed}/7; сохранено: {store.Records.Count}; отклонено: {gateway.RejectedCount}; в очереди: {gateway.PendingCount}");
Environment.ExitCode = passed == 7 ? 0 : 1;

sealed class DemoStore : IClimateStore
{
    public bool Available { get; set; } = true;
    public List<ClimateMessage> Records { get; } = [];

    public void Save(ClimateMessage message)
    {
        if (!Available) throw new IOException("Учебная имитация сбоя хранилища");
        Records.Add(message);
    }
}
